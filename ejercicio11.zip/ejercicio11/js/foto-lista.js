const PHOTO_LIST = [
    'img/conejo.jpg',
    'img/lobo.jpg',
    'img/gato.jpg',
    'img/mono.jpg',
    'img/panda.jpg',
    'img/perro.jpeg',
    'img/suricata.jpg',
    'img/tigre.jpg',    
    'img/zorro.jpg'
];