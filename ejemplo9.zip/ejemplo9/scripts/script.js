function onKeyUp(event) {
    console.log('onKeyUp:' + event.key);
    }
    document.addEventListener('keyup', onKeyUp); 